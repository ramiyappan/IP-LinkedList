
/******File containing the prototype of all functions used in the entire program********/

extern void insert(char value[50]);
extern void delete(int pos);
extern void add();
extern void look();
extern void update();
extern void del();
extern void disp();
extern void check_alias();
extern void Save();
extern void exit_this();