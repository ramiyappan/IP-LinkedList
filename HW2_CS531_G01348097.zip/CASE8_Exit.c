//*******************************************************************************************************
// Author   : Ramaswamy Iyappan
// Date     : March 13, 2202
// Subject  : This file is the main() file for the assignment2
// program  : main.c
// GMU ID   : G01348097
//*******************************************************************************************************


#include<stdlib.h>

/************************ UDF Function to terminate the program ***********************/
void exit_this()
{
    exit(0);
}